import React from 'react';
import { Github, Linkedin, Facebook, Instagram } from 'lucide-react';

const About: React.FC = () => {
  const socialLinks = [
    {
      icon: <Linkedin className="w-6 h-6" />,
      url: 'https://www.linkedin.com/in/mohamed-raashid/',
      label: 'LinkedIn'
    },
    {
      icon: <Github className="w-6 h-6" />,
      url: 'https://github.com/Raashi-d',
      label: 'GitHub'
    },
    {
      icon: <Facebook className="w-6 h-6" />,
      url: 'https://www.facebook.com/raashidh.raashidh',
      label: 'Facebook'
    },
    {
      icon: <Instagram className="w-6 h-6" />,
      url: 'https://www.instagram.com/raashi__d/',
      label: 'Instagram'
    }
  ];

  return (
    <div className="min-h-screen pt-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <h1 className="section-title">About Me</h1>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div className="bg-gray-900 dark:bg-gray-100 p-6 rounded-lg">
              <h2 className="section-subtitle">Personal Information</h2>
              <ul className="space-y-3 text-gray-300 dark:text-gray-700">
                <li><span className="text-yellow-400">Name:</span> Mohamed Raashid</li>
                <li><span className="text-yellow-400">Date of Birth:</span> February 23, 2001</li>
                <li><span className="text-yellow-400">Age:</span> 23</li>
                <li><span className="text-yellow-400">Phone:</span> +94 778 253 443</li>
                <li><span className="text-yellow-400">Address:</span> 32/2, Polgolla Road, Udathalawinna, Kandy</li>
              </ul>
            </div>
            
            <div className="bg-gray-900 dark:bg-gray-100 p-6 rounded-lg">
              <h2 className="section-subtitle">Connect With Me</h2>
              <div className="flex space-x-4">
                {socialLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-gray-300 dark:text-gray-700 hover:text-yellow-400 transition-colors"
                    aria-label={link.label}
                  >
                    {link.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="w-full aspect-square rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fit=crop&w=800&q=80"
                alt="Mohamed Raashid"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;