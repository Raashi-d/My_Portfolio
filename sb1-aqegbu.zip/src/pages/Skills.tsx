import React from 'react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      title: 'Frontend Development',
      skills: ['Flutter', 'React', 'HTML', 'CSS', 'JavaScript']
    },
    {
      title: 'Backend Development',
      skills: ['Node.js', 'Express', 'REST APIs']
    },
    {
      title: 'Database Systems',
      skills: ['MongoDB', 'MySQL']
    },
    {
      title: 'Tools and Platforms',
      skills: ['VSCode', 'Figma', 'Photoshop', 'Git']
    },
    {
      title: 'Programming Languages',
      skills: ['Python', 'Java']
    }
  ];

  return (
    <div className="min-h-screen pt-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <h1 className="section-title">My Skills</h1>
        
        <div className="grid md:grid-cols-2 gap-6">
          {skillCategories.map((category) => (
            <div key={category.title} className="bg-gray-900 p-6 rounded-lg">
              <h2 className="section-subtitle">{category.title}</h2>
              <div className="space-y-4">
                {category.skills.map((skill) => (
                  <div key={skill} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">{skill}</span>
                    </div>
                    <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-yellow-400 rounded-full transition-all duration-500"
                        style={{ width: '85%' }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Skills;